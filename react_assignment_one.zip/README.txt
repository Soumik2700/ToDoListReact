==> Open the project in vscode by using "npm run dev" command, in case you dont have the dependencies installed run "npm install" and then use "npm run dev"

==> After opening thr project type any task in the input box and click on add, the task will be added. Keep on adding as per your need.

==> use edit and delete button for editting and deleting the existing tasks.

==> use the completed task button as per your requirment. 