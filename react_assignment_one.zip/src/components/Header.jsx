import "../App.css"
function Header(){
    return(
        <>
            <h1 className="heading text-slate-500 font-bold">ToDo List</h1>
        </>
    );
}

export default Header;